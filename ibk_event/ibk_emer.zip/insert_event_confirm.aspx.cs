using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;

public partial class insert_event : System.Web.UI.Page
{
	public string myName = "";
	public string myPhone = "";
	public string friend1Phone = "";
	public string friend2Phone = "";
	public string friend3Phone = "";
	
    protected void Page_Load(object sender, EventArgs e)
    {
		string userAgent = Request.ServerVariables["HTTP_USER_AGENT"].ToString();
		
		if (userAgent.IndexOf("Windows") != -1)
		{
			Response.Redirect("invalid_access.html");
		}

    	myName = Request["myName"];
    	myPhone = Request["myPhone"];
    	friend1Phone = Request["friend1Phone"];
    	friend2Phone = Request["friend2Phone"];
    	friend3Phone = Request["friend3Phone"];
    }
}
